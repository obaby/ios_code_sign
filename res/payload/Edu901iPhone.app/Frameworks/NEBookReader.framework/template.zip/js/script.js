var pris = window.pris || {};
var YD_notice = window.YD_notice || {};
var MyApp_SearchResultPOSX = 0;
var MyApp_SearchResultPOSY = 0;
var MyApp_SearchResultcount = 0;
var MyApp_SearchResultDone = 0;
var results = "";
//屏幕宽度
var screenWidth = 0;
var screenHeight = 0;
//页面背景图及全屏图片信息
var styleObj= {
    'background-image': [],
    'background-position': [],
    'background-repeat': [],
    'background-size': [],
    'fullScreenPages': []
};
//全屏图片所在页面的array
var fullScreenArray = [];
var sectionId = 0;

var $ = function(element) {
    return {
        bind : YD_notice.bind,
        element : element
    }
}
YD_notice.bind = function(event, callback) {
    this.element.addEventListener(event, callback);
    return $(this.element);
}
YD_notice.trigger = function(element, eventName){
   var event = document.createEvent("UIEvents");
   event.initEvent(eventName, true, true);
    
  if('dispatchEvent' in element) element.dispatchEvent(event) 
}
YD_notice.addTouchEvent = function () {
    var touch = {}, touchTimeout

        function parentIfText(node) {
            return 'tagName' in node ? node : node.parentNode
        }

    var longTapDelay = 750,
        longTapTimeout

        function longTap() {
            longTapTimeout = null
            if (touch.last) {
                YD_notice.trigger(touch.el, 'longTap');
                touch = {}
            }
        }

        function cancelLongTap() {
            if (longTapTimeout) clearTimeout(longTapTimeout)
            longTapTimeout = null
        }


    var body = document.body;

    var now, delta

    $(body).bind('touchstart', function (e) {
        now = Date.now()
        delta = now - (touch.last || now)
        touch.el = parentIfText(e.touches[0].target)
        touchTimeout && clearTimeout(touchTimeout)
        touch.x1 = e.touches[0].pageX
        touch.y1 = e.touches[0].pageY
        if (delta > 0 && delta <= 250) touch.isDoubleTap = true
        touch.last = now
        longTapTimeout = setTimeout(longTap, longTapDelay)
    }).bind('touchmove', function (e) {
        cancelLongTap()
        touch.x2 = e.touches[0].pageX
        touch.y2 = e.touches[0].pageY
    }).bind('touchend', function (e) {
        cancelLongTap()

        // double tap (tapped twice within 250ms)
        if (touch.isDoubleTap) {
            YD_notice.trigger(touch.el, 'doubleTap');
            touch = {}

            // swipe
        } else if ((touch.x2 && Math.abs(touch.x1 - touch.x2) > 30) || (touch.y2 && Math.abs(touch.y1 - touch.y2) > 30)) {
            YD_notice.trigger(touch.el, 'swipe')

            touch = {}

            // normal tap
        } else if ('last' in touch) {
            YD_notice.trigger(touch.el, 'tap')

            touchTimeout = setTimeout(function () {
                touchTimeout = null
                YD_notice.trigger(touch.el, 'singleTap');
                touch = {}
            }, 250)
        }
    }).bind('touchcancel', function () {
        if (touchTimeout) clearTimeout(touchTimeout)
        if (longTapTimeout) clearTimeout(longTapTimeout)
        longTapTimeout = touchTimeout = null
        touch = {}
    })
}

function toArray(collection) {
    return Array.prototype.slice.apply(collection);
}
/**
 * 向客户端发送schema消息,替代window.location方法，防止该方法造成的load事件不触发的问题
 * @param  {string} schemeUrl 与客户端约定的消息
 */
function callByApp(schemeUrl) {
    var iframe = document.createElement("iframe");
    iframe.id = 'callByApp';
    iframe.style.border = "none";
    iframe.style.width = "1px";
    iframe.style.height = "1px";
    iframe.src = schemeUrl;
    document.body.appendChild(iframe);
    window.setTimeout(function(){
        document.body.removeChild(iframe);
    },1000)
}
var getVersion = function(versions) {
    var result = '';
    versions = versions.split('.');
    for (var i = 0; i < versions.length; i++) {
        var n = versions[i];
        if (i != 0 && n <= 9 && n.length < 2) {
            n = '0' + n;
        }
        result += n;
    }

    return result;
};
/**
 * 客户端调用，获取选中文字的位置
 * @return {string} 格式化的位置字符串 {{left,top},{width,height}}
 */
function getRectForSelectedText() {
    var selection = window.getSelection();
    var range = selection.getRangeAt(0);
    var rect = range.getBoundingClientRect();
    return '{{' + rect.left + ',' + rect.top + '}, {' + rect.width + ',' + rect.height + '}}';
}

//得到element的坐标，iphone4.4增加remark元素的查找
//点击划线的文字,点击标注客户端都调用此方法
//ipad3.1回调，获取元素位置
function getPosition(param) {
    var theElement = document.getElementById(param);
    var positionX = 0;
    var positionY = 0;
    var iw;
    var ih;
    if (theElement != null) {
        iw = theElement.offsetWidth;
        ih = theElement.offsetHeight;
    } else {
        theElement = document.querySelector('[prisid=\'' + param + '\']');
        if (theElement != null) {
            iw = theElement.offsetWidth;
            ih = theElement.offsetHeight;
        }
    }
    var bodyH = document.body.offsetHeight - 62;
    var bodyW = document.body.offsetWidth;
    var columnWidth = document.body.clientWidth;
    var paddingLeft = 25;
    if (theElement.className == 'remark') {
        //处理书籍备注的情况
        //x坐标值
        var positionX = theElement.offsetLeft;
        var pElementPositonX = theElement.offsetParent.offsetLeft;
        var pagePositionX = parseInt(pElementPositonX / columnWidth) * columnWidth + paddingLeft;
        var positionX = positionX + pagePositionX;
        //y坐标值
        var pElementPositonY = theElement.offsetParent.offsetTop;
        var positionY = theElement.offsetTop + pElementPositonY;
    } else if (theElement.tagName && theElement.tagName.toLowerCase() == 'a') {
        while (theElement != null) {
            if (ih > 33 && theElement.offsetLeft != 0) {
                positionX += parseInt(theElement.offsetLeft / columnWidth) * columnWidth + 25;
            } else {
                positionX += theElement.offsetLeft;
            }
            positionY += theElement.offsetTop;
            theElement = theElement.offsetParent;
        }
    } else {
        while (theElement != null) {
            positionX += theElement.offsetLeft;
            positionY += theElement.offsetTop;
            theElement = theElement.offsetParent;
        }
    }

    if (positionY > bodyH) {
        var paddingTop = 63;
        positionX = positionX + columnWidth;
        positionY = positionY - bodyH + paddingTop;
    }
    // var returnString = positionX + ';' + positionY + ';' + theElement.offsetWidth + ';' + theElement.offsetHeight;
    // toast('param:'+param+' left:'+positionX+' top:'+positionY+' width;'+iw+' height:'+ih);
    return positionX + ';' + positionY + ';' + iw + ';' + ih;
}
//判断是否是有边框css类的图片
function hasBorder (element) {
    var result = false;
    if ((element.className.indexOf('img-left') != -1) || (element.className.indexOf('img-right') != -1) || (element.className.indexOf('img-left') != -1)) {
        result = true;
    };
    return result;
}
/**
 * 内部getLinkPositions()调用 ,获取dom节点的位置
 * @param  {dom element} element dom节点的引用
 * @return {string}         X坐标、Y坐标、宽度、高度，用';'分隔
 */
function getPositionOfElement(element) {
    var theElement = element;
    var positionX = 0;
    var positionY = 0;
    var iw;
    var ih;

    var isMark = false; //保存当前element是否是标注按钮的flag

    if (theElement.className == 'remark' && theElement.style.display == 'none') return;
    if (theElement != null) {
        if (theElement.className == 'mark') {
            iw = 48;
            ih = 44;
            isMark = true;
        } else {
            iw = theElement.offsetWidth;
            ih = theElement.offsetHeight;
        }

    }
    var bodyH = document.body.offsetHeight - 62;
    var bodyW = document.body.offsetWidth;
    if (theElement.className == 'remark') {
        //处理书籍备注的情况
        //x坐标值
        var columnWidth = document.body.clientWidth;
        var paddingLeft = 25;
        var positionX = theElement.offsetLeft;
        var pElementPositonX = theElement.offsetParent.offsetLeft;
        var pagePositionX = parseInt(pElementPositonX / columnWidth) * columnWidth + paddingLeft;
        var positionX = positionX + pagePositionX;
        //y坐标值
        var pElementPositonY = theElement.offsetParent.offsetTop;
        var positionY = theElement.offsetTop + pElementPositonY;
    } else {
        while (theElement != null) {
            positionX += theElement.offsetLeft;
            positionY += theElement.offsetTop;
            theElement = theElement.offsetParent;
        }
    }

    //注图标点击热区扩大后调整位置
    if (isMark) {
        positionX -= 12;
        positionY -= 12;
    };

    if (positionY > bodyH) {
        var paddingTop = 63;
        positionX = positionX + columnWidth;
        positionY = positionY - bodyH + paddingTop;
    }
    return positionX + ';' + positionY + ';' + iw + ';' + ih;
}

function getNoticePosition(element){
    // var theElement = element;
    // var positionX =0;
    // var positionY =0;
    // var iw;
    // var ih;
    // var borderFlag = false;//图片是否有边框的flag

    // if(theElement.className == "remark" && theElement.style.display == "none") return;
    // if(theElement != null)
    // {   
    //     iw = theElement.offsetWidth;
    //     ih = theElement.offsetHeight;
    //     if(hasBorder(theElement)){
    //         iw -= 6;
    //         ih -= 6;
    //         borderFlag = true;
    //     }
    // }
    // var bodyH =  document.body.offsetHeight;
    // var bodyW =  document.body.offsetWidth;
    // if(theElement.className == "remark"){
    //         //处理书籍备注的情况
    //         //x坐标值
    //         var columnWidth = document.body.clientWidth;
    //         var paddingLeft = 25;
    //         var positionX = theElement.offsetLeft;
    //         var pElementPositonX = theElement.offsetParent.offsetLeft;
    //         var pagePositionX = parseInt(pElementPositonX/columnWidth)*columnWidth + paddingLeft;
    //         var positionX = positionX + pagePositionX;
            
    //         //y坐标值
    //         var pElementPositonY = theElement.offsetParent.offsetTop;
    //         var positionY = theElement.offsetTop + pElementPositonY;
    // }else{
    //     while (theElement !=null){
    //         positionX +=theElement.offsetLeft;
    //         positionY +=theElement.offsetTop;
    //         theElement =theElement.offsetParent;
    //     }
    // }

    // //跨页笔记
    // if(positionY > bodyH){
    //     var paddingTop = 63;
    //     positionX = positionX + columnWidth;
    //     positionY = positionY - bodyH + paddingTop;
    // }

    // if(borderFlag){
    //     positionX += 3;
    //     positionY += 3;
    // }

    var position = element.getBoundingClientRect();

    return {
        top:position.top,
        bottom:position.bottom,
        left:position.left,
        right:position.right
    }
}
/**
 * 内部getLinkPositions()调用，获取url节点的位置
 * @param  {dom element} element dom节点的引用
 * @return {string}     X坐标、Y坐标、宽度、高度，用';'分隔    
 */
function getUrlPositionOfElement(element) {
    var theElement = element;
    var positionX = 0;
    var positionY = 0;
    var iw;
    var ih;
    if (theElement != null) {
        iw = theElement.offsetWidth;
        ih = theElement.offsetHeight;
    }
    var bodyH = document.body.offsetHeight;
    var bodyW = document.body.offsetWidth;
    var columnWidth, paddingLeft;
    if (bodyW == 352) {
        //iphone6
        columnWidth = 375;
        paddingLeft = 20;
    } else if (bodyW == 391) {
        //iphone6plus
        columnWidth = 414;
        paddingLeft = 20;
    } else if (bodyW == 691) {
        //ipad 竖屏
        columnWidth = 768 - 44;
        paddingLeft = 33;
    } else if (bodyW == 457) {
        //ipad 横屏
        columnWidth = (1024 - 44) / 2;
        paddingLeft = 33;
    } else if (bodyW == 852) {
        //ipad 横屏一列
        columnWidth = 1024 - 44;
        paddingLeft = 128;
    } else {
        //4/5
        columnWidth = 320;
        paddingLeft = 20;
    }
    while (theElement != null) {
        if (ih > 33 && theElement.offsetLeft != 0) {
            positionX += parseInt(theElement.offsetLeft / columnWidth) * columnWidth + paddingLeft;
        } else {
            positionX += theElement.offsetLeft;
        }
        positionY += theElement.offsetTop;
        theElement = theElement.offsetParent;
    }
    return positionX + ';' + positionY + ';' + iw + ';' + ih;
}

//  客户端调用，得到所有划线、备注、标注、书籍和图片的区域
//  为了保持一致，区域之间使用','分割，区域内部元素之间使用';'分割
/**
 * 客户端调用，得到所有链接、备注和图片的区域
 * 区域之间只用','分隔，区域内部数值间使用';'分隔
 * @return {string} 上述区域的集合所组成的位置字符串
 */
function getLinkPostions() {
    var links = document.getElementsByTagName('a');
    var images = document.getElementsByTagName('img');
    var mark = document.querySelectorAll('.mark');
    var remark = document.querySelectorAll('.remark');
    var bookLinks = document.querySelectorAll('.book-link.matched');
    //var elements = toArray(links).concat(toArray(images)).concat(toArray(mark));
    var elements = toArray(images).concat(toArray(mark)).concat(toArray(remark));
    var total = elements.length;
    var result = ',';
    for (i = 0; i < total; i++) {
        var oneElement = elements[i];
        //不返回被隐藏的全屏图片的坐标值
        if(oneElement.className&&oneElement.className.toLowerCase().indexOf('full-screen') !== -1) continue;
        var rect = getPositionOfElement(oneElement);
        if (rect != null) {
            result += rect;
            result += ','
        }
    }
    /*changed in 4.2返回超链接的矩形*/
    links = toArray(links).concat(toArray(bookLinks));
    var length = toArray(links).length;
    for (var j = 0; j < length; j++) {
        var oneElement = links[j];
        var rect = getUrlPositionOfElement(oneElement);
        if (rect != null) {
            result += rect;
            result += ','
        }
    }
    return result;
}

function setVisible(param) {
    var theElement = document.getElementById(param);
    theElement.style.visibility = 'visible'
}

function sethidden(param) {
    var theElement = document.getElementById(param);
    theElement.style.visibility = 'hidden';
}

/*
 **use this function to setHightLight
 */
function setHTMLHightLightAt(path, attri) {
    var range = window.getSelection().getRangeAt(0);
    //alert(window.getSelection().toString());
    //add in iphone 4.3
    //如果选择全文则不高亮
    var _cns = range.commonAncestorContainer.childNodes;
    var _startContainerHtml = range.startContainer.textContent;
    var _flag = false;

    for (var i = 0; i < _cns.length; i++) {
        var _cn = _cns[i];
        if (_cn.tagName == 'H1' && _cn.innerText == _startContainerHtml) {
            _flag = true;
            break;
        }
    }
    //end
    var selectionContents = range.extractContents();
    //add in iphone 4.3
    for (var i = 0; i < _cns.length; i++) {
        var _cn = _cns[i];
        if (_cn.tagName == 'H1' && _flag) _cn.parentNode.removeChild(_cn);
    }
    //end
    var childNodes = selectionContents.childNodes;
    var idArr = new Array();
    toArray(childNodes).forEach(function(child) {
        if (child.tagName !== undefined && child.tagName.toLowerCase() == 'a' && child.id.indexOf('highlight') != -1) {
            var repeatDoc = document.createTextNode(child.innerHTML);
            child.parentNode.insertBefore(repeatDoc, child);
            child.parentNode.removeChild(child);
            idArr.push(child.id);
        } else if (child.tagName !== undefined && child.tagName.toLowerCase() == 'p' /*&& child.id.indexOf('highlight')!=-1*/ ) {
            var pChildNodes = child.childNodes;
            toArray(pChildNodes).forEach(function(pChild) {
                if (pChild.tagName && pChild.tagName.toLowerCase() == 'a' && pChild.id.indexOf('highlight') != -1) {
                    var repeatDoc = document.createTextNode(pChild.innerHTML);
                    pChild.parentNode.insertBefore(repeatDoc, pChild);
                    pChild.parentNode.removeChild(pChild);
                    idArr.push(pChild.id);
                }
            })
        }
    })

    var div = document.createElement('a');
    div.appendChild(selectionContents);
    range.insertNode(div);

    var _as = div.querySelectorAll('h1');
    var _ps = div.querySelectorAll('p');

    var _aArray = toArray(_as);
    var _pArray = toArray(_ps);
    _ps = _aArray.concat(_pArray);
    //Iphone4.3做了跳转的修改
    //选中单个段落
    var _hrefPath = 'pirs:' + path;
    if (_ps.length == 0) {
        div.style.backgroundColor = attri;
        div.setAttribute('href', _hrefPath);
        div.setAttribute('id', path);
        div.style.color = '#333';
        div.style.textDecoration = 'none';
    }

    for (var i = 0, l = _ps.length; i < l; i++) {
        //删除a节点
        _ps[i].parentNode.insertAdjacentElement("beforeBegin", _ps[i]);
        var p = _ps[i];
        p.innerHTML = "<a href='" + _hrefPath + "' id= '" + path + "'style='background-color:" + attri + "; color:#333; text-decoration:none'>" + p.innerHTML + "</a>";
    }
    var returnValue = new Array();
    var returnValueStr = null;
    for (var i = 0; i < idArr.length; i++) {
        var obj = document.getElementById(idArr[i]);
        var str;
        if (obj == null) {
            str = '{"id":"' + idArr[i] + '","innerText":"' + '' + '"}';
        } else {
            str = '{"id":"' + idArr[i] + '","innerText":"' + obj.innerHTML + '"}';
        }
        returnValue.push(str);
        returnValueStr = encodeURIComponent(JSON.stringify(returnValue));
        //删除多余的a标签 在标记多段落的情况下
        var aNodes = document.getElementById(idArr[i]);
        if (aNodes && aNodes.innerHTML == "") {
            aNodes.parentNode.removeChild(aNodes);
        }
    }
    if (returnValueStr) {
        return returnValueStr;
    }
};

/*
 **use this function to removeHightLight
 */
function removeHTMLHightLightAt(param) {
    //var theElement = document.getElementById(param);
    var theElements = document.querySelectorAll('#' + param);
    for (var i = 0; i < theElements.length; i++) {
        var theElement = theElements[i];
        var thestring = theElement.innerHTML;
        var div = document.createElement('span');
        div.id = param;
        div.innerHTML = thestring;
        theElement.parentNode.insertBefore(div, theElement);
        theElement.parentNode.removeChild(theElement);

        var childs = div.childNodes;
        //childs_len = childs.length;
        for (var j = 0, len = childs.length; j < len; j++) {
            //删除段落节点上的样式
            var child = childs[j];
            var cChilds = child.childNodes;
            for (var k = 0, l = cChilds.length; k < l; k++) {
                cChild = cChilds[k];
                if (cChild.className == param) {
                    cChild.parentNode.innerHTML = cChild.innerHTML;
                }
            }
            //删除div上的id
            div.parentNode.insertBefore(childs[j].cloneNode(true), div);
        }

        div.parentNode.removeChild(div);
    }

}
/**
 * 根据客户端传递的笔记选区的起始终止段落信息和起始终止段落offset，设置range选区
 * @param {element} node  dom节点，根据段落id获取的段落节点的引用
 * @param {int} index 起始或终止offset
 * @param {string} type  start or end 是设置起点还是终点
 */
function setRange(range, node, index, type) {
    var charIndex = 0, found = false;
    function traverseTextNodes(node, index, type) {
        if (node.nodeType == 3) {
            var nextCharIndex = charIndex + node.length;
            if (!found && index >= charIndex && index <= nextCharIndex) {
                found = true;
                if(type === 'start'){
                    range.setStart(node, index - charIndex); 
                }else{
                    range.setEnd(node, index - charIndex);
                }
            };
            charIndex = nextCharIndex;
        } else {
            for (var i = 0, len = node.childNodes.length; i < len; ++i) {
                traverseTextNodes(node.childNodes[i], index, type); 
            }
        }
    }
    traverseTextNodes(node, index, type);
};
/*
 *use this function to add bookNote on html
 */
function setHTMLBookNoteAt(path, attri, noteInfo) {
    var range;
    if(noteInfo){
        noteInfo = JSON.parse(decodeURIComponent(noteInfo));
        if(document.querySelector('p[data-paragraphid="'+ noteInfo.startParaId +'"]') && document.querySelector('p[data-paragraphid="'+ noteInfo.endParaId +'"]')){
            range = document.createRange();
            var startPara = document.querySelector('p[data-paragraphid="'+ noteInfo.startParaId +'"]');
            var endPara = document.querySelector('p[data-paragraphid="'+ noteInfo.endParaId +'"]');
            setRange(range, startPara, noteInfo.startOffset, 'start');
            setRange(range, endPara, noteInfo.endOffset, 'end');
        }else{
            throw new Error('paragraphid not exist');
        }
    }else{
        range = window.getSelection().getRangeAt(0);
    }
    //如果当前选中的标记文字为已有标记的a标签内的所有文字，则将该a标签作为新的选中区域，
    if (range.startContainer.parentNode && range.startContainer.parentNode.tagName.toLowerCase() == 'a' && range.startContainer.parentNode.innerText == range) {
        var newRange = document.createRange();
        newRange.selectNode(range.startContainer.parentNode);
        range = newRange;
    }
    //选中单个整段时，如果段尾有标注.mark,将该标注排除出选中区域
    if(range.commonAncestorContainer.className !== 'm-content'){
        var _cns = range.commonAncestorContainer.childNodes;
        //不选中标注节点
        if (_cns[_cns.length - 1] && _cns[_cns.length - 1].className && _cns[_cns.length - 1].className.toLowerCase() == 'mark' && range.startContainer.parentNode.nextSibling && range.startContainer.parentNode.nextSibling.className && range.startContainer.parentNode.nextSibling.className.toLowerCase() == 'mark') {
            range.setEndBefore(_cns[_cns.length - 1]);
        }
    }
    /**
     * 获取range在段落中的offset
     * @param  {dom element} element    range的startcontainer或者endcontainer
     * @param  {number} partOffset range的api中返回的range在startcontainer或者endcontainer中的offset
     * @return {json}        段落id 和  起始点或者终止点在段落中的实际的offset
     */
    function getParaAndOffset(element, partOffset) {
        var paraOffset = 0;
        var _para = element.parentNode;
        while(_para.nodeName.toLowerCase() !== 'p' ){
            var _childNodes = _para.childNodes;
            for (var i = 0; i < _childNodes.length; i++) {
                var _child = _childNodes[i];
                if(_child !== element){
                    paraOffset += _child.textContent.length;
                }else{
                    break;
                }
            }
            _para = _para.parentNode;
            element = element.parentNode;
        }
        var _childNodes = _para.childNodes;
        for (var i = 0; i < _childNodes.length; i++) {
            var _child = _childNodes[i];
            if(_child !== element){
                paraOffset += _child.textContent.length;
            }else{
                break;
            }
        };
        paraOffset += partOffset;
        return {
            paraId : _para.dataset.paragraphid,
            offset : paraOffset
        };
    };
    //记录选中的起始段id，起始点段offset，结束段id，结束点段offset
    var startInfo = getParaAndOffset(range.startContainer, range.startOffset);
    var endInfo = getParaAndOffset(range.endContainer, range.endOffset);
    var selectInfo = {
        startParaId : startInfo.paraId,
        startOffset : startInfo.offset,
        endParaId : endInfo.paraId,
        endOffset : endInfo.offset
    };
    //是否是只选中单个段落或者单个段落的一部分
    var isSinglePara = range.commonAncestorContainer.nodeType === 3 || range.commonAncestorContainer.className.toLowerCase() != 'm-content' ? true : false;

    //处理标注区域重复
    var selectionContents = range.extractContents();

    //处理重复区域中的标注
    var remark = selectionContents.querySelector('.remark');
    if (remark) {
        remark.parentNode.removeChild(remark)
    };  
    var _childNodes = selectionContents.childNodes;
    //如果文字选择刚好停留在.mark标注之前，将会出现标注同时出现在选区中和选区外，所以删除选区内的最后的这个标注节点
    if(_childNodes[_childNodes.length-1].className && _childNodes[_childNodes.length-1].className.toLowerCase() === 'mark'){
       var mark = _childNodes[_childNodes.length-1];
       mark.parentNode.removeChild(mark) 
    }
    var idArr = new Array();
    var singleParaNoteStr = '';
    toArray(_childNodes).forEach(function(child) {
        if (child.tagName !== undefined && child.tagName.toLowerCase() == 'a' && child.id.indexOf('highlight') != -1) {
            idArr.push(child.id);
            if(!isSinglePara){
              child.outerHTML = child.innerHTML;  
            }
        } else if (child.tagName !== undefined && child.tagName.toLowerCase() == 'p') {
            var pChildNodes = child.childNodes;
            toArray(pChildNodes).forEach(function(pChild) {
                if (pChild.tagName && pChild.tagName.toLowerCase() == 'a' && pChild.id.indexOf('highlight') != -1) {
                    idArr.push(pChild.id);
                    if(!isSinglePara){
                        pChild.outerHTML = pChild.innerHTML;
                    }
                }
            })
        }
        //过滤空段落
        if(child.tagName && child.tagName.toLowerCase() == 'p' && child.innerText && child.innerText.trim().replace(/[\r\n]|\s{2,}/g, '') == ''){
            child.parentNode.removeChild(child);
        }
        //笔记填回原文\
        var _text = '';
        if(isSinglePara){
            if(child.nodeName === 'SPAN'){
                //标注
                _text = child.outerHTML;
            }else if(child.nodeName === 'A'){
                //已有笔记a标签
                _text = child.innerHTML;
            }else{
                _text = child.textContent ? child.textContent : '';
            }
            singleParaNoteStr += _text;
        }
    })
    if(isSinglePara){
        var singleLink = document.createElement('a');
        singleLink.id = path;
        singleLink.href = 'pirs:' + path;
        singleLink.style.color = 'inherit';
        singleLink.style.position = 'relative';
        singleLink.style.textDecoration = 'none';
        singleLink.style.fontSize = 'inherit';
        singleLink.style.backgroundColor = attri;
        singleLink.innerHTML = singleParaNoteStr+'<span id="'+ path +'_remark" class="remark"></span>';
        range.insertNode(singleLink);
    }else{
        var currentPara = {};
        for(var i = 0; i < _childNodes.length; i++){
            var _child = _childNodes[i];
            if(_child.textContent.trim().replace(/[\r\n]|\s{2,}/g, '') && _child.dataset){
                var _childId = _child.dataset.paragraphid;
                if(_childId === selectInfo.startParaId){
                    var _originalPara = document.querySelector('p[data-paragraphid="'+ _childId +'"]');
                    _originalPara.innerHTML += '<a href="pirs:'+ path +'" id="'+ path +'" style="color:inherit;position:relative;text-decoration:none;font-size:inherit;background-color: '+ attri +';">'+ _child.innerHTML +'</a>';
                    currentPara = _originalPara;
                }else if(_childId === selectInfo.endParaId){
                    var _originalPara = document.querySelector('p[data-paragraphid="'+ _childId +'"]');
                    _originalPara.innerHTML = '<a href="pirs:'+ path +'" id="'+ path +'" style="color:inherit;position:relative;text-decoration:none;font-size:inherit;background-color: '+ attri +';">'+ _child.innerHTML +'<span id="'+ path +'_remark" class="remark"></span></a>' + _originalPara.innerHTML;
                }else{
                    _child.innerHTML = '<a href="pirs:'+ path +'" id="'+ path +'" style="color:inherit;position:relative;text-decoration:none;font-size:inherit;background-color: '+ attri +';">'+ _child.innerHTML +'</a>';
                    var cloneNode = _child.cloneNode(true);
                    currentPara.insertAdjacentElement('afterend', cloneNode)
                    currentPara = cloneNode;
                }
            }
        }
    }
    //返回值
    var returnObj = {}

    //有重复区域，通知客户端
    var returnValue=new Array();
    
    for(var i = 0; i<idArr.length; i++){
        var obj = document.getElementById(idArr[i]);
        var str;
        if(obj==null){
            str='{"id":"'+idArr[i]+'","innerText":"'+''+'"}';
        }else{
            str='{"id":"'+idArr[i]+'","innerText":"'+obj.innerText+'"}';
        }
        returnValue.push(str);
        // returnValueStr =  encodeURIComponent(JSON.stringify(returnValue));
        //删除多余的a标签 在标记多段落的情况下
        var aNodes = document.getElementById(idArr[i]);
        if(aNodes && aNodes.innerHTML==""){
            aNodes.parentNode.removeChild(aNodes);
        }
    }
    returnObj = {
        selectInfo : selectInfo,
        repeatNote : returnValue
    }
    console.log('returnObj:',returnObj);
    window.getSelection().removeAllRanges();
    range.detach();
    range = null;
    return encodeURIComponent(JSON.stringify(returnObj));
}

/*
 *use this function to show or hide bookNoteIcon
 */
function toggleBookNoteIcon(id, status) {
    var _iconId = id + '_remark';
    var _icon = document.querySelector('#' + _iconId);
    if (status) {
        _icon.style.display = 'inline-block';
    } else {
        _icon.style.display = 'none';
    }
}
/**
 * 客户端调用，改变某一笔记的背景颜色
 * @param  {String} param 笔记id
 * @param  {string} attri 代表颜色值的字符串
 */
function changeHTMLBookNoteAt(param, attri) {
    var _theElements = document.querySelectorAll('#' + param);
    for (var i = 0; i < _theElements.length; i++) {
        var _theElement = _theElements[i];
        _theElement.style.backgroundColor = attri;
    }
}
/**
 * 客户端调用，根据笔记id删除对应的笔记信息
 * @param  {string} param 笔记的id
 */
function removeHTMLBookNoteAt(param) {
    var _remarkEle = document.querySelector('#' + param + '_remark');
    if (_remarkEle) {
        _remarkEle.parentNode.removeChild(_remarkEle);
    }

    var theElements = document.querySelectorAll('#' + param);
    for (var i = theElements.length - 1; i >= 0; i--) {
        var _theElement = theElements[i];
        if (_theElement.tagName.toLowerCase() == 'span') {
            _theElement.parentNode.removeChild(_theElement);
        } else {
            var thestring = _theElement.innerHTML;
            var div = document.createElement('span');
            div.id = param;
            div.innerHTML = thestring;
            _theElement.parentNode.insertBefore(div, _theElement);
            _theElement.parentNode.removeChild(_theElement);
            var childs = div.childNodes;
            for (var j = 0, len = childs.length; j < len; j++) {
                //删除段落节点上的样式
                var child = childs[j];
                var cChilds = child.childNodes;
                for (var k = 0, l = cChilds.length; k < l; k++) {
                    cChild = cChilds[k];
                    if (cChild.className == param) {
                        cChild.parentNode.innerHTML = cChild.innerHTML;
                    }
                }
                //删除div上的id
                div.parentNode.insertBefore(childs[j].cloneNode(true), div);
            }
            div.parentNode.removeChild(div);
        }
    }
}

// helper function, recursively searches in elements and their child nodes
function MyApp_HighlightAllOccurencesOfStringForElement(element, keyword) {
    if (element) {
        if (element.nodeType == 3) { // Text node
            while (true) {
                var value = element.nodeValue; // Search for keyword in text node
                var idx = value.toLowerCase().indexOf(keyword);

                if (idx < 0) break; // not found, abort

                var span = document.createElement('highlight');
                span.className = 'MyAppHighlight';
                span.style.backgroundColor = 'yellow';
                var text = document.createTextNode(value.substr(idx, keyword.length));
                span.appendChild(text);

                var rightText = document.createTextNode(value.substr(idx + keyword.length));
                element.deleteData(idx, value.length - idx);

                var next = element.nextSibling;
                element.parentNode.insertBefore(rightText, next);
                element.parentNode.insertBefore(span, rightText);

                element = rightText;
                MyApp_SearchResultCount++; // update the counter

                // _console += 'Span className: ' + span.className + '\n';
                // _console += 'Span position: (' + getPos(span).x + ', ' + getPos(span).y + ')\n';

                results += getPos(span).x + ',' + getPos(span).y + ';';

                results;
            }
        } else if (element.nodeType == 1) { // Element node
            if (element.style.display != 'none' && element.nodeName.toLowerCase() != 'select') {
                for (var i = element.childNodes.length - 1; i >= 0; i--) {
                    MyApp_HighlightAllOccurencesOfStringForElement(element.childNodes[i], keyword);
                }
            }
        }
    }
}

function getPos(el) {
    // yay readability
    for (var lx = 0, ly = 0; el != null; lx += el.offsetLeft, ly += el.offsetTop, el = el.offsetParent);
    return { x: lx, y: ly };
}

// the main entry point to start the search
function MyApp_HighlightAllOccurencesOfString(keyword) {
    MyApp_RemoveAllHighlights();
    MyApp_HighlightAllOccurencesOfStringForElement(document.body, keyword.toLowerCase());
}

// helper function, recursively removes the highlights in elements and their childs
function MyApp_RemoveAllHighlightsForElement(element) {
    if (element) {
        if (element.nodeType == 1) {
            if (element.getAttribute('class') == 'MyAppHighlight') {

                for (var i = 0; i < element.childNodes.length; i++) {
                    element.parentNode.insertBefore(element.childNodes[i].cloneNode(true), element);
                }
                element.parentNode.removeChild(element);

                return true;
            } else {
                var normalize = false;
                for (var i = element.childNodes.length - 1; i >= 0; i--) {
                    if (MyApp_RemoveAllHighlightsForElement(element.childNodes[i])) {
                        normalize = true;
                    }
                }
                if (normalize) {
                    element.normalize();
                }
            }
        }
    }
    return false;
}
/**
 * 客户端调用，切换到夜间模式
 */
function nightMode() {
    var body = document.getElementsByTagName('body')[0];
    body.className = 'nightMode';
}
/**
 * 客户端调用，切换到日间普通模式
 */
function normalMode() {
    var body = document.getElementsByTagName('body')[0];
    body.className = '';
}

//为指定的文章背景设置对应字体颜色
function switchMode(index) {
    index = parseInt(index);
    var cssStr = '';
    var color = '#151515';
    var remarkBackColorCssStr = '';
    switch (index) {
        case 4:
            color = '#fff';
            remarkBackColorCssStr = 'a[id^=pirs]{background-color:rgba(255,209,32,.12)!important}';
            break;
        case 5:
            color = '#666';
            remarkBackColorCssStr = 'a[id^=pirs]{background-color:rgba(255,209,32,.12)!important}';
            break;
    }
    cssStr = 'body p{color: '+  color +';} body h1,body h2, body h3, body h4, body h5, body h6{color: '+ color +';} .section{color: '+  color +';}';
    cssStr += remarkBackColorCssStr;  
    var switchModeCss = document.querySelector('#switchModeCss');
    if (switchModeCss) {
        switchModeCss.parentNode.removeChild(switchModeCss);
    }
    var switchMode_style = document.createElement('style');
    switchMode_style.setAttribute('type', 'text/css');
    switchMode_style.setAttribute('id', 'switchModeCss');
    switchMode_style.innerHTML = cssStr;
    var head = document.querySelector('head');
    head.appendChild(switchMode_style);
}

// the main entry point to remove the highlights
function MyApp_RemoveAllHighlights() {
    MyApp_SearchResultCount = 0;
    results = '';
    MyApp_RemoveAllHighlightsForElement(document.body);
}

/**
 * 显示提示信息，自用方法
 * @param  {string} words 想要显示的文字信息
 */
function toast(words) {
    if(document.querySelector('.m-mask')){
        var words = document.querySelector('.toast-words').innerText + ' ' + words;
        document.querySelector('.m-mask').parentNode.removeChild(document.querySelector('.m-mask'));
        var mask = document.createElement('DIV');
        mask.className = 'm-mask';
        mask.innerHTML = '<div class="content">\
                        <p class="toast-words">'+ words +'</p>\
                    </div>';
        document.body.appendChild(mask);
        setTimeout(function () {
            document.body.removeChild(mask);
        },3000)
    }else{
        var mask = document.createElement('DIV');
        mask.className = 'm-mask';
        mask.innerHTML = '<div class="content">\
                        <p class="toast-words">'+ words +'</p>\
                    </div>';
        document.body.appendChild(mask);
        setTimeout(function () {
            document.body.removeChild(mask);
        },3000)
    }
}

/**
 * 更新书内搜索标签内容，跳转书籍详情或者搜索页
 * @param  {json} searchResult name 书籍名称 id 书籍id multi 多本书籍
 */
function updateBookLink(searchResult) {
    if(searchResult){
        var bookName = searchResult.name;
        var bookLinks = document.querySelectorAll('.book-link[data-book-name="'+ bookName +'"]');
        // alert(bookLinks.length);
        if(searchResult.id){
            for (var i = bookLinks.length - 1; i >= 0; i--) {
                bookLinks[i].setAttribute('data-book-id', searchResult.id);
                bookLinks[i].className = 'book-link matched';
            }
        }else if(searchResult.multi){
            for (var i = bookLinks.length - 1; i >= 0; i--) {
                bookLinks[i].setAttribute('data-book-multi', true);
                bookLinks[i].className = 'book-link matched';
            }
        }
    }
}
/**
 * 发起检查书名标签搜索请求，使用透传接口
 */
pris.checkBookLink = function() {
    var bookLinks = document.querySelectorAll('.book-link');
    var length = bookLinks.length;
    var bookNameObj = {};
    var bookNameArr = [];
    for (var i = 0; i < length; i++) {
        var bookLink = bookLinks[i];
        if (bookLink.dataset.bookId) continue;
        var bookName = bookLink.dataset.bookName;
        if (bookNameObj[bookName]) continue;
        bookNameObj[bookName] = true;
        bookNameArr.push({
            name: bookName
        });
    }
    if (bookNameArr.length) {
        var sendData = {
            search: bookNameArr
        }
        callByApp('web:wapChannel;action=searchBookName&data=' + JSON.stringify(sendData));
    }
}

/**
 * 透传接口统一回调函数，有客户端调用
 * @param  {string} action   透传业务action名称
 * @param  {json string} response 协议返回结果 示例
 * {
        'resCode':0,
        'resDesc':',
        'result': [
        {
          'name': '阿甘正传',
          'id': '21a331b0434440a38f7341c607da5ffe_4'
        },
        {
          'name': '大学',
          'multi': true,
        }]
    }
 */
pris.wapChannelCallback = function(action, response) {
    // toast('callback action:' + action + 'response:' + decodeURIComponent(response));
    if (typeof response == 'string') {
        response = JSON.parse(decodeURIComponent(response));
    }
    if (response.resCode != 0) return;
    switch (action) {
        case 'searchBookName':
            // toast('searchBookName callback');
            //书内搜索，透传查询书名回调处理
            var searchResult = response.result;
            if (searchResult) {
                for (var i = searchResult.length - 1; i >= 0; i--) {
                    updateBookLink(searchResult[i]);
                }
            }
            break;
    }
}
//改变字体大小
/* level:字体大小的等级
 * bookType:书籍类型  0：普通书籍;1: 精编书籍；2： 精编杂志
 */
function updateFontsize(level, bookType) {
    var realLevels = [0, 1, 2, 3, 5, 7, 9, 11, 13, 15, 17];
    var realLevel = realLevels[level];
    var size = 10 + realLevel;
    if (window.pris.device.toLowerCase() != 'iphone') {
        size += 2;
    }
    //记录当前font-size为精编图片对齐用
    fontSize = size;
    var mark = parseInt(realLevel / 3) - 5;
    var csstext;
    if (parseInt(bookType) == 0) {
        csstext = 'body h1{font-size: ' + (size + 3) + 'px!important;}' +
            'body h2{font-size: ' + (size + 2) + 'px!important;} body h3{font-size: ' + (size + 2) + 'px!important;}' +
            'body h4{font-size: ' + (size + 2) + 'px!important;} body h5{font-size: ' + (size + 1) + 'px!important;} ' +
            'body h6{font-size: ' + (size + 1) + 'px!important;}' +
            'body p,body pre,body p *,.yd-font{font-size: ' + size + 'px!important;}' +
            '.mark{margin-bottom:' + mark + 'px;}';
    } else if (parseInt(bookType) == 1 || parseInt(bookType) == 2) {
        csstext = 'html,body p,body pre,body p *,.yd-font{font-size: ' + size + 'px;}' +
                    '.mark{margin-bottom:' + mark + 'px;}';
    }
    var dynamicCss = document.querySelector('#dynamicCss');
    if (dynamicCss) dynamicCss.parentNode.removeChild(dynamicCss);
    var dynamic_style = document.createElement('style');
    dynamic_style.setAttribute('type', 'text/css');
    dynamic_style.setAttribute('id', 'dynamicCss');
    dynamic_style.innerHTML = csstext;
    var head = document.querySelector('head');
    head.appendChild(dynamic_style);
}
/**
 * 根据客户端的字体配置信息拼装css字体设置字符串
 * @param  {string} name 字体名称
 * @param  {string} path 字体在设备上的存储位置
 * @param  {int} type 0代表字体启用，1代表字体未启用 
 * @return {string}      拼装好的css字体设置字符串
 */
pris.makeFontFace = function(name, path, type) {
    var str = '';
    if (path != null && path != '') {
        str += '@font-face{font-family: "' + name + '";src: url(' + path + ');\
    font-style: normal;font-weight: normal;}';
    }
    if (type == null || type == 0) {
        if (name == '汉仪旗黑50') {
            str += 'body,body p,body p span{font-family:"Lora-Regular" , "' + name + '" !important;}';
            str += 'body h1, body h2, body h3, body h4, body h5, body h6{font-family:"汉仪旗黑65" !important;}';
        } else {
            str += 'body,body p,body p span{font-family:"' + name + '" !important;}';
        }
    }

    return str;
}

/**
 * 客户端调用，设置书籍的字体，根据webview中注入的window.pris中的字体配置信息，设置相应的字体
 */
pris.updateFontFamily = function() {
    if (pris == null || pris.font_family == null)
        return;
    var font = pris.font_family;
    for (var i = 0; i < font.length; i++) {
        f = font[i];
        var cssStr = pris.makeFontFace(f.name, f.path, f.type);
        var head = document.getElementsByTagName('head');
        var style = document.createElement('style');
        style.setAttribute('type', 'text/css');
        style.appendChild(document.createTextNode(cssStr));
        head[0].appendChild(style);
    }
}()

/**
 * 设置根据封面标题的背景色设置整个封面的背景色
 */
pris.updateCoverCss = function() {
        var covers = document.querySelectorAll('.cover');
        for (var i = 0; i < covers.length; i++) {
            var cover = covers[i];
            var coverH = cover.querySelector('h1') || cover.querySelector('h2') || cover.querySelector('h3');
            if (coverH) {
                var hBackGround = coverH.style.backgroundColor;
                if (hBackGround) {
                    cover.style.backgroundColor = hBackGround;
                }
            }
        }
    };
/**
 * 利用caretRangeFromPoint方法实现统计当前页书籍的字数功能
 * @return {int} 字数
 */
pris.getCurrentPageFontCount = function() {
    var fontCount = 0;
    var deviceHeight = document.body.clientHeight;

    var coordinatesMatrix = {
        '480': {
            startX: 25,
            startY: 50,
            endX: 300,
            endY: 426
        },
        '568': {
            startX: 25,
            startY: 50,
            endX: 297,
            endY: 512
        },
        '667': {
            startX: 25,
            startY: 50,
            endX: 350,
            endY: 620
        },
        '736': {
            startX: 25,
            startY: 50,
            endX: 391,
            endY: 689
        }
    }
    var coordinates = coordinatesMatrix[deviceHeight];
    var startRange = document.caretRangeFromPoint(coordinates.startX, coordinates.startY);
    var endRange = document.caretRangeFromPoint(coordinates.endX, coordinates.endY);
    if (endRange) {
        var endNode = document.createElement('span');
        endNode.style.display = 'none';
        endRange.insertNode(endNode);
        if(startRange){
            startRange.setEndAfter(endNode);
            var pageText = startRange.toString().trim().replace(/[\r\n]|\s{2,}/g, '');
            fontCount = pageText.length;
            endNode.parentNode.removeChild(endNode);
        }
    }
    return fontCount;
}
/**
 * 客户端调用，获取当前页的文字内容
 * @return {string} 文字内容
 */
pris.getCurrentPageText = function() {
    var pageText = '';
    var deviceHeight = document.body.clientHeight;

    var coordinatesMatrix = {
        '480': {
            startX: 25,
            startY: 50,
            endX: 300,
            endY: 426
        },
        '568': {
            startX: 25,
            startY: 50,
            endX: 297,
            endY: 512
        },
        '667': {
            startX: 25,
            startY: 50,
            endX: 350,
            endY: 620
        },
        '736': {
            startX: 25,
            startY: 50,
            endX: 391,
            endY: 689
        }
    }
    var coordinates = coordinatesMatrix[deviceHeight];
    var startRange = document.caretRangeFromPoint(coordinates.startX, coordinates.startY);
    var endRange = document.caretRangeFromPoint(coordinates.endX, coordinates.endY);
    if (endRange) {
        var endNode = document.createElement('span');
        endNode.style.display = 'none';
        endRange.insertNode(endNode);
        if(startRange){
            startRange.setEndAfter(endNode);
            pageText = startRange.toString().trim().replace(/[\r\n]|\s{2,}/g, '');
            endNode.parentNode.removeChild(endNode);
        }
    }
    return pageText;
}
/**
 * 客户端调用，获取当前页首个文字所在的章节id以及它的偏移量
 * @return {string} '{"id":"4a1d3b8f26e645fcac55029ea48c2478_p","offset":0}'类似这样格式的json字符串, 包含章节id及偏移量offset
 */
pris.getCurrentPageParaIdAndOffset =  function () {
    var result = {};
    var deviceHeight = document.body.clientHeight;

    var coordinatesMatrix = {
        '480': {
            startX: 25,
            startY: 50,
            endX: 300,
            endY: 426
        },
        '568': {
            startX: 25,
            startY: 50,
            endX: 297,
            endY: 512
        },
        '667': {
            startX: 25,
            startY: 50,
            endX: 350,
            endY: 620
        },
        '736': {
            startX: 25,
            startY: 50,
            endX: 391,
            endY: 689
        }
    }
    var coordinates = coordinatesMatrix[deviceHeight];
    var range = document.caretRangeFromPoint(coordinates.startX, coordinates.startY);
    if(range){
        var para = range.commonAncestorContainer;
        var nodeName = para.nodeName.toLowerCase();
        while(nodeName !== 'p' && nodeName.indexOf('h') === -1){
            para = para.parentNode;
            nodeName = para.nodeName.toLowerCase();
        }
        if(para.dataset.paragraphid){
            result.id = para.dataset.paragraphid;
            result.offset = range.startOffset;
        }
    }
    return JSON.stringify(result);
}
/**
 * 客户端调用，根据id获取划线部分的文字内容
 * @param  {string} id 划线元素的id
 * @return {string}    文字内容
 */
pris.getHTMLContentById = function (id) {
    var _element = document.querySelectorAll('#' + id);
        result = '';
    if(_element.length){
        for (var i = 0; i < _element.length; i++) {
            result += _element[i].innerText
        }
    }
    return result;
}
/**
 * 客户端调用，获取本章节起始到选中文字之前的文字数量
 * @return {number} 文字数量
 */
pris.getSelectionIndex = function () {
    var index = -1;
    var range = window.getSelection().getRangeAt(0);
    var selectedElement = range.startContainer;
    var selectedIndex = range.startOffset;
    var newRange = document.createRange();
    newRange.setStartBefore(document.querySelector('.m-content p'));
    newRange.setEnd(selectedElement, selectedIndex);
    var newRangeText = newRange.toString().trim().replace(/[\r\n]|\s{2,}/g, '')
    index = newRangeText.length;
    return index;
}
/**
 * 为styleObj中添加全屏图片显示所需信息
 */
function setFullScreenImg(type) {
    var images = document.querySelectorAll("img.full-screen");
    for (var i = 0; i < images.length; i++) {
        var img = images[i];
        var imgWidth = img.offsetWidth;
        var imgHeight = img.offsetHeight;
        img.setAttribute('imgWidth', imgWidth);
        img.setAttribute('imgHeight', imgHeight);
        if(screenWidth/screenHeight >= imgWidth/imgHeight){
            //如果屏幕宽高比大于图片宽高比，图片宽度等于屏幕宽度，图片的上下部分需要裁剪
            var imgNewWidth = screenWidth;
            var imgNewHeight = imgNewWidth*imgHeight/imgWidth;
            var imgTopDiff = (imgNewHeight - screenHeight)/2;
        }
        // img.setAttribute('real-src', img.getAttribute('src'));
        // img.setAttribute('src','http://cdn.easyread.163.com/images/grey.gif');
        if(!type){
            var imgLeft = img.offsetLeft;
            var pageNum = Math.floor(imgLeft/screenWidth);
            fullScreenArray.push(pageNum);
            styleObj['background-image'].push('url('+ img.getAttribute('src') +') ') ;
            styleObj['background-repeat'].push('no-repeat');
            // styleObj['background-position'].push(pageNum * screenWidth + 'px top');
            // styleObj['background-size'].push(screenWidth + 'px 100%');
            if(imgTopDiff){
                styleObj['background-position'].push(pageNum * screenWidth + 'px -'+imgTopDiff);
                styleObj['background-size'].push(imgNewWidth + 'px '+ imgNewHeight + 'px'); 
            }else{
                styleObj['background-position'].push(pageNum * screenWidth + 'px top');
                styleObj['background-size'].push(screenWidth + 'px 100%'); 
            }
            styleObj['fullScreenPages'].push(pageNum);
        }
    };
}
/**
 * 读取章节中储存的章节背景图信息并设置背景图
 */
function setBackgroundImg() {
    var imgInfoElements = document.querySelectorAll('[data-imgurl]');
    for (var i = 0; i < imgInfoElements.length; i++) {
        var ele = imgInfoElements[i];
        var imgLeft = ele.offsetLeft;
        var imgUrl = ele.dataset.imgurl;
        var pageNum = Math.floor(imgLeft/screenWidth);
        styleObj['background-image'].push('url('+ imgUrl +') ') ;
        styleObj['background-position'].push(pageNum * screenWidth + 'px top');
        styleObj['background-repeat'].push('no-repeat');
        styleObj['background-size'].push(screenWidth + 'px 100%');
    }
    if(styleObj['background-image'].length){
        //save to localStorage
        // if(sectionId){
        //     localStorage.setItem('backgroundSectionInfo_'+sectionId, JSON.stringify(styleObj));
        // }
        var backgroundStyle = document.createElement('style');
        backgroundStyle.type = 'text/css'
        backgroundStyle.id = 'backgroundStyle';
        var styleStr = 'body {';
        for(var key in styleObj){
            if(key !== 'fullScreenPages'){
               styleStr += key + ' : ' + styleObj[key] + ';';  
            }
        }
        styleStr += '}'
        backgroundStyle.innerText = styleStr;
        document.head.appendChild(backgroundStyle);
    }
}
/**
 * 遍历所有的a链接，提取出笔记和划线的链接的href另存为hrefsrc，过滤其他链接
 */
function updateNoteLinks() {
    var links = document.querySelectorAll('a');
    var length = links.length;
    if(length){
        for(var i = 0; i < length; i++){
            var link = links[i];
            var href = link.getAttribute('href');
            link.setAttribute('hrefsrc', href);
            link.removeAttribute('href');
        }
    }
}
/**
 * 事件代理，监控页面的所有点击事件
 */
function monitorTouch() {
    window.bookNoteTimer = 0;
    //以下的事件代理其实只有第一条remark生效，具体原因不明，估计是因为ios webview为了响应用户的触摸，从而对点击事件的过滤控制造成
    $(document.body).bind("tap", function(event) {
        var target = event.target;
        if (target.className.toLowerCase() === 'remark') {
            event.preventDefault();
            event.stopPropagation();
            //笔记icon
            //如果当前有恢复笔记href的timer，取消这个timer，防止触发href的跳转
            if(bookNoteTimer){
                window.clearTimeout(bookNoteTimer);
            }
            //防止父元素a标签的链接被触发，先去除a标签的链接，储存是hrefsrc
            if (target.parentNode && target.parentNode.href) {
                target.parentNode.setAttribute('hrefsrc', target.parentNode.href);
                target.parentNode.removeAttribute('href');
            }
            var pos = getNoticePosition(target);
            var remark = {};
            remark.id = target.id;
            remark.position = { top: pos.top, bottom: pos.bottom, left: pos.left, right: pos.right };
            callByApp('web:getbooknoteclick:' + JSON.stringify(remark));
            //当笔记icon不再被点击后1000ms后，将href加回
            bookNoteTimer =  setTimeout(function() {
                console.log('reset href');
                target.parentNode.setAttribute('href', target.parentNode.getAttribute('hrefsrc'));
            }, 1000)
        } else if (target.className.toLowerCase() === 'mark') {
            if(target.parentNode && target.parentNode.tagName.toLowerCase() === 'a'){
                target.parentNode.setAttribute('hrefsrc', target.parentNode.href);
                target.parentNode.removeAttribute('href');
                setTimeout(function() {
                    target.parentNode.setAttribute('href', target.parentNode.getAttribute('hrefsrc'));
                }, 500)
            }
            //书籍标注
            var pos = getNoticePosition(target);
            var mark = {};
            mark.content = target.title;
            mark.position = { top: pos.top, bottom: pos.bottom, left: pos.left, right: pos.right };
            callByApp("web:getbookmarkclick:" + JSON.stringify(mark));
        } /*else if (target.tagName.toLowerCase() === 'img') {
            //书籍图片
            var pos = getNoticePosition(target);
            var img = {};
            img.src = target.src;
            img.title = target.title;
            img.position = { top: pos.top, bottom: pos.bottom, left: pos.left, right: pos.right };
            alert('proxy img');
            callByApp('web:getbookimgclick:' + JSON.stringify(img));
        } */else if(target.className.toLowerCase().indexOf('book-link') !== -1){
            //书内书名搜索匹配后的span.book-link
            event.stopPropagation();
            var linkClass = target.className.toLowerCase();
            if(linkClass.indexOf('matched') === -1) return;
            var bookId = target.dataset.bookId;
            var bookMulti = target.dataset.bookMulti;
            if(bookId){
                callByApp('web:getbookpreview;data='+bookId);
            }else if(bookMulti){
                var bookName = target.dataset.bookName;
                callByApp('web:goSearchPage;searchData={"data":"'+ bookName +'","type":"1"};');
            }
        } else if (target.tagName.toLowerCase() === 'a') {
            var src = target.href || target.getAttribute('hrefsrc');
            if (!target.href) target.setAttribute('href', src);
            //对于高亮或者笔记直接href跳转，非以上情况，则如下处理(老代码，不确定是否仍有使用)
            if (src.indexOf('pirs_highlight') === -1) {
                var pos = getNoticePosition(target);
                var a = {};
                a.src = src;
                a.title = target.title;
                a.position = { top: pos.top, bottom: pos.bottom, left: pos.left, right: pos.right };
                callByApp('web:getbookurlclick:' + JSON.stringify(a));
            }
        }
    })
    //适配Ios8的图片和标注点击事件
    var touch = {}, touchTimeout,now, delta;;
    var longTapDelay = 750,
        longTapTimeout

    function parentIfText(node) {
            return 'tagName' in node ? node : node.parentNode
        }

    function cancelLongTap() {
            if (longTapTimeout) clearTimeout(longTapTimeout)
            longTapTimeout = null
        } 

    function longTap() {
            longTapTimeout = null
            if (touch.last) {
                YD_notice.trigger(touch.el, 'longTap');
                touch = {}
            }
        }
    //图片的点击事件
    var imgs = document.querySelectorAll("img");
    for(var i=0;i<imgs.length;i++){
        $(imgs[i]).bind('touchstart', function (e) {
            now = Date.now()
            delta = now - (touch.last || now)
            touch.el = parentIfText(e.touches[0].target)
            touchTimeout && clearTimeout(touchTimeout)
            touch.x1 = e.touches[0].pageX
            touch.y1 = e.touches[0].pageY
            if (delta > 0 && delta <= 250) touch.isDoubleTap = true
            touch.last = now
            longTapTimeout = setTimeout(longTap, longTapDelay)
        }).bind('touchmove', function (e) {
            cancelLongTap()
            touch.x2 = e.touches[0].pageX
            touch.y2 = e.touches[0].pageY
        }).bind('touchend', function (e) {
            cancelLongTap()

            // double tap (tapped twice within 250ms)
            if (touch.isDoubleTap) {
                YD_notice.trigger(touch.el, 'doubleTap');
                touch = {}

                // swipe
            } else if ((touch.x2 && Math.abs(touch.x1 - touch.x2) > 30) || (touch.y2 && Math.abs(touch.y1 - touch.y2) > 30)) {
                YD_notice.trigger(touch.el, 'swipe')

                touch = {}

                // normal tap
            } else if ('last' in touch) {
                YD_notice.trigger(touch.el, 'tap')
                touchTimeout = setTimeout(function () {
                    touchTimeout = null
                    YD_notice.trigger(touch.el, 'singleTap');
                    touch = {}
                }, 250)
            }
        }).bind('touchcancel', function () {
            if (touchTimeout) clearTimeout(touchTimeout)
            if (longTapTimeout) clearTimeout(longTapTimeout)
            longTapTimeout = touchTimeout = null
            touch = {}
        })
        $(imgs[i]).bind("tap",function(e){
            var $el = e.target;
            var pos = getNoticePosition($el);
            var img = {};
            img.src = $el.src;
            img.title = $el.title;
            img.position = {top:pos.top,bottom:pos.bottom,left:pos.left,right:pos.right};
            window.location.href = "web:getbookimgclick:" + JSON.stringify(img);
        })
    }
}
/**
 * 实现版权信息末段间距效果
 */
function setCopyrightParaMargin() {
    var copyrrightParas = document.querySelectorAll('.yd-copyright');
    if(copyrrightParas.length){
        var length = copyrrightParas.length;
        copyrrightParas[length-1].classList.add('last');
    }
}
/**
 * 控制书籍正文段落首行是否缩进
 * @param  {string} needIndent 'yes' 代表缩进 ，'no'代表不缩进
 */
pris.toggleTextIndent = function (needIndent) {
    if(document.querySelector('#indentStyle')){
       document.querySelector('#indentStyle').parentNode.removeChild(document.querySelector('#indentStyle')); 
    }
    var indentStr = needIndent === 'yes' ? '2em' : '0em';
    var cssStr = 'body p.section{text-indent:'+ indentStr +';}';
    var indentStyle = document.createElement('style');
    indentStyle.id = 'indentStyle';
    indentStyle.innerText = cssStr;
    document.querySelector('head').appendChild(indentStyle);
    //根据段落缩进美化背景色段落
    beautifyParaColor(needIndent);
}
/**
 * 客户端调用，获取当前章节有哪些页存在全屏图片，从而隐藏底部信息栏
 * @return {string} 用逗号分隔的有全屏图片的页面序号,没有则为"",有则类似"1","1,3"
 */
pris.getFullScreenPages = function () {
    var result = '';
    if(styleObj['fullScreenPages'].length){
        result = styleObj['fullScreenPages'].toString();
    }
    return result;
}
/**
 * 客户端调用，根据段落id和段落偏移量获取偏移位置的坐标
 * @param  {string} paraId 段落唯一id
 * @param  {number} offset 目的位置的文字偏移量 不小于0不大于段落文字数量的整数
 * @return {string}        返回值格式为'positionX;positionY;width;height'；width和height可以忽略
 *                         如果段落id对应的段落不存在或者offset不符要求,返回空字符串''；
 *                         如果offset值大于段落字数，返回'0;0'
 */
pris.getPositionByParaOffset = function (paraId, offset) {
    var result = '';
    var para = document.querySelector('[data-paragraphid="'+ paraId +'"]');
    if(para && typeof parseInt(offset) === 'number' && offset >= 0){
        var range = document.createRange();
        setRange(range, para, offset, 'start');
        setRange(range, para, offset, 'end');
        if(range.commonAncestorContainer !== document){
            var tagElement = document.createElement('span');
            range.insertNode(tagElement);
            result = getUrlPositionOfElement(tagElement);
            tagElement.parentNode.removeChild(tagElement);
        }
    }
    return result;
}
/**
 * 美化背景色段落，根据段落首行缩进与否写入不同的样式
 */
function beautifyParaColor(needIndent) {
    var colorfulParas = document.querySelectorAll('p[style*="background-color"]');
    var indentStr = needIndent === 'yes' ? '2em' : '0em';
    for (var i = 0; i < colorfulParas.length; i++) {
        var para = colorfulParas[i],
            style = window.getComputedStyle(para),
            textIndent = style.textIndent;
            paraLineHeight = parseInt(style.lineHeight.match(/\d+/)[0]);
            paraHeight = parseInt(style.height.match(/\d+/)[0]);
            if(paraLineHeight === paraHeight){
                para.style.display = 'inline-block';
                para.style.marginLeft = indentStr;
                if(textIndent !== '0px'){
                    para.style.textIndent = '0';
                    para.style.marginLeft = '2em';
                }
            }
    }
}
/**
 * 获取当前章节的所有笔记的id
 * @return {string} 当前章节所有的笔记的id，逗号“,”分隔,没有则为空""
 */
pris.getAllBookNotes = function () {
    var notesArr = [],
        notesObj = {},
        bookNotes = document.querySelectorAll('a[id^=pirs]');
    for (var i = 0; i < bookNotes.length; i++) {
        var bookNote = bookNotes[i];
        var id = bookNote.id;
        if(id && !notesObj[id]){
            notesObj[id] = 1;
            notesArr.push(id);
        } 
    }
    return notesArr.toString();
}

window.addEventListener('DOMContentLoaded', function() {
    // var monitorScript = document.createElement('script');
    // monitorScript.src = 'http://10.240.100.85:8082/target/target-script.js';
    // monitorScript.id = 'monitorScript';
    // document.querySelector('head').appendChild(monitorScript);
    
    //实现版权信息末段间距效果
    setCopyrightParaMargin();
    //背景色段落显示效果优化
    // beautifyParaColor();
    //加入tap支持，消除300ms延时
    YD_notice.addTouchEvent();
    //fontsize init
    if (window.pris && window.pris.fontLevel) {
        updateFontsize(window.pris.fontLevel, window.pris.booktype);
    }
    if (window.pris && window.pris.textIndent) {
        pris.toggleTextIndent(window.pris.textIndent);
    }
    pris.updateCoverCss();
    monitorTouch();
    if(document.querySelector('.j-chapter')){
        sectionId = document.querySelector('.j-chapter').dataset.paragraphid;
        if(localStorage.getItem('backgroundSectionInfo_'+sectionId)){
            styleObj = JSON.parse(localStorage.getItem('backgroundSectionInfo_'+sectionId));
            var backgroundStyle = document.createElement('style');
            backgroundStyle.type = 'text/css'
            backgroundStyle.id = 'backgroundStyle';
            var styleStr = 'body {';
            for(var key in styleObj){
                if(key !== 'fullScreenPages'){
                   styleStr += key + ' : ' + styleObj[key] + ';';  
                }
            }
            styleStr += '}'
            backgroundStyle.innerText = styleStr;
            document.head.appendChild(backgroundStyle);
            setFullScreenImg('already');
        }
    }
    screenWidth = document.documentElement.clientWidth;
    screenHeight = document.documentElement.clientHeight;
})
window.addEventListener('load', function () {
    if(!document.querySelector('#backgroundStyle')){
        setFullScreenImg();
        setBackgroundImg();
    }
}, false)
